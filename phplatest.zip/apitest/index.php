<?php
    include "./db_info.php";//생성했던 DB연결 파일 호출. db연결이 완료된다.

    $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH); //호출한 uri을 가져옴
    $uri = explode('/', $uri); // uri를 ('/') 단위로 쪼갬

    if($uri[4] !== 'info') // 마지막 로케이션이 /info로 끝나는 경우만 통과
    {
       header("HTTP/1.1 404 Not Found"); //그렇지 않은 경우 404 에러를 헤더에 삽입
        exit(); //함수 종료
    }

    $requestMethod = $_SERVER["REQUEST_METHOD"]; // 메서드 방식을 가져옴. GET인지 POST인지 필터
    switch ($requestMethod)  //switch문으로 메서드 방식을 필터링함
    {
        case 'GET' : //이번 기능은 GET에서만 작동하므로 다음 코드 실행
            require_once 'check_server.php'; //server_check.php를 호출하고 종료함. -> 호출 URI의 마지막 경로가 /info로 끝나고, GET으로 호출한 경우는 check_server.php 이라는 파일을 호출해서 데이터를 통신
            berak;

        default:
            #code...
            break;
    }
?>