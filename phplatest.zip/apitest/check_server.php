<?php
    include "db_info.php";
    $select_query = "select count(*) as counter from board"; //테이블 칼럼수 요청
    $result = mysqli_query($conn =dbconn() ,$select_query);
    $result_model = $result->fetch_array();

    if($result_model != 0)
    {
        echo json_encode(array('countUser'=>$result_model['counter']));
        return;
    }

    mysqli_close($conn);
?>