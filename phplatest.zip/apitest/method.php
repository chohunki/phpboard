<?php
    $method = $_SERVER["REQUEST_METHOD"];

    echo $method;
    $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH); //호출한 uri을 가져옴
    echo "<br>";
    echo $_SERVER['REQUEST_URI'];
    echo "<br>";
    echo $uri;
    echo "<br>";
    $uri2 = explode('/', $uri); // uri를 ('/') 단위로 쪼갬
    echo $uri2[2];

?>
